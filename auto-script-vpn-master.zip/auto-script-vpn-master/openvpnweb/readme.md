<h1>Script by Jiraphat Yuenying</h1>

<p>วิธีติดตั้ง</p>
<p>รันคำสั่งตามนี้</p>
<div>
    <ul>
        <li>wget https://raw.githubusercontent.com/jiraphaty/auto-script-vpn/master/openvpnweb/install_web_ub14.sh</li>
        <li>chmod +x install_web_ub14.sh</li>
        <li>./install_web_ub14.sh</li>
    </ul>
</div>
<p>เข้าเว็บตามไอพีโฮสของคุณ เช่น 192.168.1.1/install </p>
<h1>สคริปของระบบต่าง ๆ</h1>
 <ul>
        <li>
            Xampp บนวินโด้ว ติดตั้งผ่าน Powershell
            <ul>
                <li>https://raw.githubusercontent.com/jiraphaty/auto-script-vpn/master/openvpnweb/install_web_window.ps1</li>
            </ul>
        </li>
        <li>
            Debian 8
            <ul>
                <li>https://raw.githubusercontent.com/jiraphaty/auto-script-vpn/master/openvpnweb/install_web_db8.sh</li>
            </ul>
        </li>
        <li> 
            Debian 9
            <ul>
                <li>https://raw.githubusercontent.com/jiraphaty/auto-script-vpn/master/openvpnweb/install_web_db9.sh</li>
            </ul>
        </li>
         <li> 
           Ubuntu 14
            <ul>
                <li>https://raw.githubusercontent.com/jiraphaty/auto-script-vpn/master/openvpnweb/install_web_ub14.sh</li>
            </ul>
        </li>
        <li> 
           Ubuntu 16
            <ul>
                <li>https://raw.githubusercontent.com/jiraphaty/auto-script-vpn/master/openvpnweb/install_web_ub16.sh</li>
            </ul>
        </li>
    </ul>
<h2>สคริปท์ติดตั้ง openvpn https://github.com/jiraphaty/auto-script-vpn</h2>
