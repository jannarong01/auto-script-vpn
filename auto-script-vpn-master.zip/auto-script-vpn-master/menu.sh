#!/bin/bash
#Menu

echo -e "================================MENU====================================="
echo -e "* menu       : เรียกดู menu"
echo -e "* member     : ดูจำนวน user"
echo -e "* usernew     : สร้าง user ใหม่"
echo -e "* speedtest     : ทดสอบความเร็วเน็ต"
echo -e "* userd     : ลบ user"
echo -e "* trial     : สร้าง user ทดลอง"
echo -e "========================================================================="
echo -e ""
